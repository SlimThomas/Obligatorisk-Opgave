﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text.Json;
using System.Threading;

class TCPServer
{
    static void Main(string[] args)
    {
        TcpListener listener = new TcpListener(IPAddress.Any, 6000); // Ny port
        listener.Start();
        Console.WriteLine("Server is running on port 6000...");

        while (true)
        {
            TcpClient client = listener.AcceptTcpClient();
            Thread clientThread = new Thread(HandleClient);
            clientThread.Start(client);
        }
    }

    static void HandleClient(object obj)
    {
        TcpClient client = (TcpClient)obj;
        NetworkStream stream = client.GetStream();
        StreamReader reader = new StreamReader(stream);
        StreamWriter writer = new StreamWriter(stream) { AutoFlush = true };

        try
        {
            // Læs kommando fra klienten
            string command = reader.ReadLine();
            Console.WriteLine("Command received: " + command);

            // Vent på at modtage talene som én string
            string numbers = reader.ReadLine();
            Console.WriteLine("Numbers received: " + numbers);
            string[] parts = numbers.Split(' ');

            // Tjek om vi fik to tal
            if (parts.Length != 2 || !int.TryParse(parts[0], out int tal1) || !int.TryParse(parts[1], out int tal2))
            {
                // Fejlbesked i JSON-format, hvis input er forkert
                string errorResponse = JsonSerializer.Serialize(new { error = "Invalid numbers format. Expected two integers." });
                writer.WriteLine(errorResponse);
                return;
            }

            // Behandl kommandoen og generer svar
            string responseJson;
            switch (command)
            {
                case "Random":
                    Random rnd = new Random();
                    int randomNumber = rnd.Next(tal1, tal2 + 1);
                    responseJson = JsonSerializer.Serialize(new { result = randomNumber });
                    break;

                case "Add":
                    int sum = tal1 + tal2;
                    responseJson = JsonSerializer.Serialize(new { result = sum });
                    break;

                case "Subtract":
                    int difference = tal1 - tal2;
                    responseJson = JsonSerializer.Serialize(new { result = difference });
                    break;

                default:
                    // Fejlbesked, hvis ukendt kommando
                    responseJson = JsonSerializer.Serialize(new { error = "Unknown method. Supported methods: Random, Add, Subtract." });
                    break;
            }

            // Send JSON svar tilbage til klienten
            writer.WriteLine(responseJson);
            Console.WriteLine("Sent response: " + responseJson);
        }
        catch (Exception e)
        {
            Console.WriteLine("Error: " + e.Message);
            string errorResponse = JsonSerializer.Serialize(new { error = "Server error occurred." });
            writer.WriteLine(errorResponse);
        }
        finally
        {
            client.Close();
        }
    }
}
