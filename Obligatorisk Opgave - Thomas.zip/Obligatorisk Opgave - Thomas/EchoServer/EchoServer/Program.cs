﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;

class TCPServer
{
    static void Main(string[] args)
    {
        TcpListener listener = new TcpListener(IPAddress.Any, 5000);
        listener.Start();
        Console.WriteLine("Serveren kører");

        while (true)
        {
            TcpClient client = listener.AcceptTcpClient();
            Thread clientThread = new Thread(HandleClient);
            clientThread.Start(client);
        }
    }

    static void HandleClient(object obj)
    {
        TcpClient client = (TcpClient)obj;
        NetworkStream stream = client.GetStream();
        StreamReader reader = new StreamReader(stream);
        StreamWriter writer = new StreamWriter(stream) { AutoFlush = true };

        try
        {
            
            string command = reader.ReadLine();
            Console.WriteLine("Command received: " + command);

          
            writer.WriteLine("Input numbers");

            
            string numbers = reader.ReadLine();
            string[] parts = numbers.Split(' ');
            int number1 = int.Parse(parts[0]);
            int number2 = int.Parse(parts[1]);

         
            string result = "";

            if (command == "Random")
            {
                Random rnd = new Random();
                int randomNumber = rnd.Next(number1, number2 + 1); 
                result = randomNumber.ToString();
            }
            else if (command == "Add")
            {
                int sum = number1 + number2;
                result = sum.ToString();
            }
            else if (command == "Subtract")
            {
                int difference = number1 - number2;
                result = difference.ToString();
            }
            else
            {
                result = "Unknown command";
            }

            
            writer.WriteLine(result);
            Console.WriteLine($"Result sent: {result}");
        }
        catch (Exception e)
        {
            Console.WriteLine("Error: " + e.Message);
        }
        finally
        {
            client.Close();
        }
    }
}
