﻿using System.Net.Sockets;
using System;
using System.IO;
using System.Net.Sockets;

class TCPClient
{
    static void Main(string[] args)
    {
        try
        {
            using (TcpClient client = new TcpClient("127.0.0.1", 5000))
            using (NetworkStream stream = client.GetStream())
            using (StreamReader reader = new StreamReader(stream))
            using (StreamWriter writer = new StreamWriter(stream) { AutoFlush = true })
            {
                // Step 1: Ask user for command (Random, Add, Subtract)
                Console.WriteLine("Enter command (Random, Add, Subtract):");
                string command = Console.ReadLine();
                writer.WriteLine(command); // Send command to server

                // Step 2: Server responds "Input numbers"
                string serverResponse = reader.ReadLine();
                Console.WriteLine("Server: " + serverResponse);

                // Step 3: Ask user for two numbers
                Console.WriteLine("Enter two numbers separated by space:");
                string numbers = Console.ReadLine();
                writer.WriteLine(numbers); // Send numbers to server

                // Step 4: Receive and display result
                string result = reader.ReadLine();
                Console.WriteLine("Server result: " + result);
            }
        }
        catch (Exception e)
        {
            Console.WriteLine("Error: " + e.Message);
        }
    }
}
