using TrophyProject;

namespace TrophyRepoTest
{
    [TestClass]
    public class TrophyRepositoryTest
    {
        private TrophyRepository _repository;

        [TestInitialize]
        public void Setup() 
        {
            _repository = new TrophyRepository();
        }

        [TestMethod]
        public void AddTrophyRepository()
        {
            // Arrange
            var newTrophy = new Trophy() { Competition = "Marathon", Year = 2021 };

            // Act 
            var AddedTrophy = _repository.Add(newTrophy);

            // Assert

            Assert.IsNotNull(AddedTrophy);
            Assert.AreEqual(6, AddedTrophy.Id);
            Assert.AreEqual("Marathon", AddedTrophy.Competition);
            Assert.AreEqual(2021, AddedTrophy.Year);

        }

        [TestMethod]
        public void GetByIdRepository()
        {

            //Act 
            var trophy = _repository.GetById(1);

            //Assert 
            Assert.IsNotNull(trophy);
            Assert.AreEqual(1, trophy.Id);
            Assert.AreEqual("World Cup", trophy.Competition);
            Assert.AreEqual(2018, trophy.Year);

        }

        [TestMethod]
        public void RemoveTrophyRepository()
        {
            //Arrange
            var TrophyIdToRemove = 1;

            // Act
            var TrophyRemoved = _repository.Remove(TrophyIdToRemove);
            var retrievedTrophy = _repository.GetById(TrophyIdToRemove);

            //Assert
            Assert.IsNotNull(TrophyRemoved);
            Assert.AreEqual(1, TrophyRemoved.Id);
            Assert.IsNull(retrievedTrophy); // Trophy should be removed
        }

        [TestMethod]
        public void UpdateTrophyRepository()
        {
            //Arrange
            var TrophyToUpdate = new Trophy() { Id = 1, Competition = "World Cup", Year = 2022 };

            //Act 
            var result = _repository.Update(TrophyToUpdate);
            var retrievedTrophy = _repository.GetById(1);

            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("World Cup", result.Competition);
            Assert.AreEqual(2022, result.Year);

            Assert.AreEqual("World Cup", retrievedTrophy.Competition);
            Assert.AreEqual(2022, retrievedTrophy.Year);


        }

        public void GetRepositoryFilteredSorted()
        {
            //Act
            var result = _repository.Get(yearAfter: 2010, competitionIncludes: "World", orderBy: "competition_asc").ToList();


            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(2, result.Count());
            Assert.AreEqual(2014, result.First().Year);
            Assert.AreEqual(2018, result.Last().Year);
        }






        
    }
}