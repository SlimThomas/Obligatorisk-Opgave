﻿namespace TrophyProject
{
    public class Trophy
    {

        public int Id { get; set; }
        public string Competition { get; set; }
        public int Year { get; set; }
        

        public Trophy()
        {

        }

        public override string ToString()
        {
            return Id + " - " + Competition + " - " + Year;
        }

        public void ValidateCompetition()
        {
            if (Competition == null)
            {
                throw new ArgumentNullException("Competition must not be Null"); 
            }
            if (Competition.Length < 3)
            {
                throw new ArgumentException("Competition must have at least 3 characters");
            }
        }

        public void ValidateYear()
        {
            if (Year < 1970 || Year > 2024 )
            {
                throw new ArgumentException("Year must be between 1970 and 2024");
            }
        }

        public void Validate()
        {
            ValidateCompetition();
            ValidateYear();
        }


    }
}
