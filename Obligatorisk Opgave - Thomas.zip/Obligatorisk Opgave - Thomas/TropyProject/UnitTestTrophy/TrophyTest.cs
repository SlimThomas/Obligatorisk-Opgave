using TrophyProject;

namespace UnitTestTrophy
{
    [TestClass]
    public class TrophyTest
    {
        private Trophy trophyTrue = new Trophy { Id = 1, Competition = "World Cup", Year = 2018 };
        private Trophy trophyYearTooSoon = new Trophy { Id = 2, Competition = "World Cup", Year = 2025 };
        private Trophy trophyYearTooOld = new Trophy { Id = 3, Competition = "World Cup", Year = 1969 };
        private Trophy trophyCompetitionTooShort = new Trophy { Id = 4, Competition = "Wo", Year = 2018 };
        private Trophy trophyCompetitionNull = new Trophy { Id = 5, Competition = null, Year = 2018 };


        [TestMethod]
        public void ToStringTest()
        {
            string str = trophyTrue.ToString();
            Assert.AreEqual("1 - World Cup - 2018", str);
        }

        [TestMethod]
        public void ValidateCompetitionTest()
        {
            trophyTrue.ValidateCompetition();
            Assert.ThrowsException<ArgumentNullException>(() => trophyCompetitionNull.ValidateCompetition());
            Assert.ThrowsException<ArgumentException>(() => trophyCompetitionTooShort.ValidateCompetition());
        }

        [TestMethod]
        public void ValidateYearTest()
        {
            trophyTrue.ValidateYear();
            Assert.ThrowsException<ArgumentException>(() => trophyYearTooSoon.ValidateYear());
            Assert.ThrowsException<ArgumentException>(() => trophyYearTooOld.ValidateYear());
        }

    }
}